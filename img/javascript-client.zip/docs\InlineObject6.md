# SpoonacularApi.InlineObject6

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredientList** | **String** | The ingredient list of the recipe, one ingredient per line. | 
**servings** | **Number** | The number of servings that you can make from the ingredients. | 
**includeNutrition** | **Boolean** | Whether nutrition data should be added to correctly parsed ingredients. | [optional] 


